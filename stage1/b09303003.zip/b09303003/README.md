# C++ Chatroom Project

## Compile
使用 Make 來 Compile
```
make
```
## Usage

開啟 Server 的指令如下
```
./server <portnumber>
```

開啟 Client 的指令如下
```
./client <server_ip> <portnumber>
```